'urlfilter.cgi' => 'Block unwanted content with the URL filter for the web proxy service.',
'urlfilter.dat' => 'Check logs for attempted access from clients to domains and URLs that have been blocked by the URL filter.',
